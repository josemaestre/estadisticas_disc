/opt/pentaho/pdi81/data-integration/kitchen.sh /file=/home/jgm/dm/disc.kjb

